# setup.py 
import setuptools 

setuptools.setup(
    name="party",
    version="0.0.1",
    author="rafsan",
    author_email="rafsan.rafi159@gmail.com",
    description="Practical Python code",
    packages=setuptools.find_packages(),
)